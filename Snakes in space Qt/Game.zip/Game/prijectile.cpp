#include "prijectile.h"

Prijectile::Prijectile(QObject *parent) : QObject(parent)
{

}

Prijectile::~Prijectile()
{

}

