#include "example.h"

Example::Example(QWidget *parent)
    : QWidget(parent)
{
}

Example::~Example()
{

}
